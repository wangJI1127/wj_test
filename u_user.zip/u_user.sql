INSERT INTO `u_user` (`id`, `username`, `email`, `password`, `create_time`, `last_login_time`, `status`, `account`) VALUES (14, 'admin', NULL, '123456', NULL, NULL, 1, 1500.00);
INSERT INTO `u_user` (`id`, `username`, `email`, `password`, `create_time`, `last_login_time`, `status`, `account`) VALUES (16, 'zhangsan', NULL, '123456', NULL, NULL, 1, 3500.00);
